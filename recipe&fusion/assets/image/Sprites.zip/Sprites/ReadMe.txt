READ ME

Hello, my name is Erika!

You have downloaded all the sprites I made for the game Little Chef.
The game can be played on here: https://truebiger.itch.io/little-chef

All of these sprites are licensed under the CC0, which means you are free to use them however you want (except for reselling them as they are).

Crediting is still highly appreciated!
Hello erika - https://www.youtube.com/@helloerika

I hope you enjoy the sprites!
Cheers